import reactDOM from "react-dom";
import { App } from "./App";

reactDOM.render(<App />, document.querySelector("#root"));
